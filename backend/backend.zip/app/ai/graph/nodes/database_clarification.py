from typing import Any

from app.ai.graph.state import ChatState


def database_clarification_node(
    state: ChatState,
) -> dict[str, Any]:

    question = state.get(
        "database_clarification_question",
    )

    if not question:
        question = "Please specify the year you mean."

    return {
        "messages": [
            {
                "role": "assistant",
                "content": question,
            }
        ],
    }
