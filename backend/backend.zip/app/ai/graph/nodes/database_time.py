from calendar import monthrange
from collections.abc import Callable
from dataclasses import dataclass
from datetime import date
from typing import Any

from app.ai.graph.state import ChatState, GraphContext
from app.ai.schemas.database import (
    DatabaseQueryPlan,
    TimeScope,
)
from app.modules.analytics.repository import AnalyticsRepository
from langgraph.runtime import Runtime
from sqlmodel import Session


@dataclass(slots=True)
class TemporalResolution:
    """Resolved date range or clarification requirement."""

    resolved: bool
    start_date: date | None = None
    end_date: date | None = None

    clarification_required: bool = False
    clarification_question: str | None = None


class DatabaseTemporalResolver:
    """Resolves analytical time expressions deterministically."""

    def __init__(
        self,
        repository: AnalyticsRepository,
    ) -> None:
        self.repository = repository

    def resolve(
        self,
        plan: DatabaseQueryPlan,
    ) -> TemporalResolution:

        temporal = plan.temporal

        # ----------------------------------------------
        # ALL TIME
        # ----------------------------------------------

        if temporal.scope == TimeScope.ALL_TIME:
            return TemporalResolution(
                resolved=True,
            )

        # ----------------------------------------------
        # EXPLICIT YEAR
        # ----------------------------------------------

        if temporal.scope == TimeScope.YEAR and temporal.year is not None:
            return TemporalResolution(
                resolved=True,
                start_date=date(
                    temporal.year,
                    1,
                    1,
                ),
                end_date=date(
                    temporal.year + 1,
                    1,
                    1,
                ),
            )

        # ----------------------------------------------
        # EXPLICIT MONTH + YEAR
        # ----------------------------------------------

        if (
            temporal.scope == TimeScope.MONTH
            and temporal.month is not None
            and temporal.year is not None
        ):
            return self._resolve_month(
                year=temporal.year,
                month=temporal.month,
            )

        # ----------------------------------------------
        # MONTH WITHOUT YEAR
        # ----------------------------------------------

        if (
            temporal.scope == TimeScope.MONTH
            and temporal.month is not None
            and temporal.year is None
        ):
            years = self.repository.get_order_years()

            if not years:
                return TemporalResolution(
                    resolved=False,
                    clarification_required=False,
                    clarification_question=(
                        "No order dates are available in the database."
                    ),
                )

            if len(years) == 1:
                return self._resolve_month(
                    year=years[0],
                    month=temporal.month,
                )

            year_text = ", ".join(str(year) for year in years)

            return TemporalResolution(
                resolved=False,
                clarification_required=True,
                clarification_question=(
                    "Which year do you mean? "
                    f"The database contains data for: "
                    f"{year_text}."
                ),
            )

        # ----------------------------------------------
        # EXPLICIT DATE RANGE
        # ----------------------------------------------

        if temporal.scope == TimeScope.DATE_RANGE:
            if temporal.start_date is None or temporal.end_date is None:
                raise ValueError(
                    "Date range is incomplete.",
                )

            return TemporalResolution(
                resolved=True,
                start_date=temporal.start_date,
                end_date=temporal.end_date,
            )

        raise ValueError(
            "Unable to resolve database time scope.",
        )

    @staticmethod
    def _resolve_month(
        year: int,
        month: int,
    ) -> TemporalResolution:

        last_day = monthrange(
            year,
            month,
        )[1]

        start = date(
            year,
            month,
            1,
        )

        end = date(
            year,
            month,
            last_day,
        )

        # Convert inclusive last day to exclusive next day.
        exclusive_end = end.fromordinal(end.toordinal() + 1)

        return TemporalResolution(
            resolved=True,
            start_date=start,
            end_date=exclusive_end,
        )


def create_database_time_resolver_node(
    session_factory: Callable[[], Session],
):
    async def database_time_resolver_node(
        state: ChatState,
        runtime: Runtime[GraphContext],
    ) -> dict[str, Any]:

        del runtime

        raw_plan = state.get(
            "database_plan",
        )

        if raw_plan is None:
            raise ValueError(
                "Database query plan is missing.",
            )

        plan = DatabaseQueryPlan.model_validate(
            raw_plan,
        )

        with session_factory() as session:
            repository = AnalyticsRepository(
                session=session,
            )

            resolver = DatabaseTemporalResolver(
                repository=repository,
            )

            resolution = resolver.resolve(
                plan,
            )

        return {
            "database_time_resolved": (resolution.resolved),
            "database_start_date": (resolution.start_date),
            "database_end_date": (resolution.end_date),
            "database_clarification_required": (resolution.clarification_required),
            "database_clarification_question": (resolution.clarification_question),
        }

    return database_time_resolver_node
