from typing import Literal

from app.ai.graph.state import ChatState

DatabaseTimeRoute = Literal[
    "database_executor",
    "database_clarification",
]


def route_after_database_time(
    state: ChatState,
) -> DatabaseTimeRoute:

    if state.get(
        "database_clarification_required",
        False,
    ):
        return "database_clarification"

    if state.get(
        "database_time_resolved",
        False,
    ):
        return "database_executor"

    raise ValueError(
        "Database time could not be resolved.",
    )
