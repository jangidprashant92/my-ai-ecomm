from typing import Any

from langchain.agents.middleware import AgentMiddleware
from langchain.agents.middleware.types import AgentState
from langchain_core.messages import AIMessage, HumanMessage


class StripHistoricalReasoningMiddleware(AgentMiddleware):
    """
    Removes old reasoning traces before a new model turn.

    Important:
    We only clean messages BEFORE the latest user message.

    This means an active tool-call / HITL sequence belonging
    to the current turn is preserved.
    """

    @property
    def name(self) -> str:
        return "strip_historical_reasoning"

    def before_model(
        self,
        state: AgentState[Any],
        runtime: Any,
    ) -> dict[str, Any] | None:

        messages = state.get("messages", [])

        if not messages:
            return None

        # Find the latest user message.
        latest_user_index = -1

        for index in range(
            len(messages) - 1,
            -1,
            -1,
        ):
            if isinstance(
                messages[index],
                HumanMessage,
            ):
                latest_user_index = index
                break

        if latest_user_index <= 0:
            return None

        cleaned_messages = list(messages)
        changed = False

        # Only clean previous turns.
        for index in range(latest_user_index):
            message = messages[index]

            if not isinstance(
                message,
                AIMessage,
            ):
                continue

            cleaned_message = message.model_copy(
                deep=True,
            )

            # Remove reasoning blocks from content.
            if isinstance(
                cleaned_message.content,
                list,
            ):
                new_content = [
                    block
                    for block in cleaned_message.content
                    if not (
                        isinstance(block, dict) and block.get("type") == "reasoning"
                    )
                ]

                if new_content != cleaned_message.content:
                    cleaned_message.content = new_content
                    changed = True

            # Remove provider-specific reasoning fields.
            additional_kwargs = dict(cleaned_message.additional_kwargs or {})

            removed = False

            for key in (
                "reasoning",
                "reasoning_content",
            ):
                if key in additional_kwargs:
                    del additional_kwargs[key]
                    removed = True

            if removed:
                cleaned_message.additional_kwargs = additional_kwargs
                changed = True

            cleaned_messages[index] = cleaned_message

        if not changed:
            return None

        return {
            "messages": cleaned_messages,
        }
