from datetime import datetime

from app.models.order import Order
from sqlmodel import Session, func, select


class AnalyticsRepository:
    """Persistence operations for analytical queries."""

    def __init__(
        self,
        session: Session,
    ) -> None:
        self.session = session

    def count_orders(
        self,
        start_date: datetime | None = None,
        end_date: datetime | None = None,
    ) -> int:
        """Count orders within an optional date range."""

        statement = select(func.count()).select_from(Order)

        if start_date is not None:
            statement = statement.where(
                Order.order_purchase_timestamp >= start_date,
            )

        if end_date is not None:
            statement = statement.where(
                Order.order_purchase_timestamp < end_date,
            )

        result = self.session.exec(
            statement,
        ).one()

        return int(result)

    def get_order_years(self) -> list[int]:
        """Return distinct years represented in order data."""

        statement = (
            select(
                func.strftime(
                    "%Y",
                    Order.order_purchase_timestamp,
                )
            )
            .distinct()
            .order_by(
                func.strftime(
                    "%Y",
                    Order.order_purchase_timestamp,
                )
            )
        )

        rows = self.session.exec(
            statement,
        ).all()

        return [int(year) for year in rows if year is not None]
