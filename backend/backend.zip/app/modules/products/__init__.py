"""Product application module."""
